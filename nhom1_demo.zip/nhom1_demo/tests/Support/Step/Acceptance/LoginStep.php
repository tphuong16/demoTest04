<?php

namespace Step\Acceptance;

class LoginStep extends \AcceptanceTester
{
    public function loginToFacebook($email, $password)
    {
        $this->amOnPage('/'); // Assuming the Facebook login page URL is '/'

        // Fill in the email and password fields and click the login button
        $this->fillField(['name' => 'email'], $email);
        $this->fillField(['name' => 'pass'], $password);
        $this->click(['name' => 'login']);
    }

    public function seeLoginPage()
    {
        $this->seeElement(['name' => 'email']);
        $this->seeElement(['name' => 'pass']);
        $this->seeElement(['name' => 'login']);
    }

    public function seeLoginFailedErrorMessage()
    {
        // Add assertions here to check if the login failed and an error message is displayed
    }

    public function seeHomePageAfterLogin()
    {
        // Add assertions here to check if the login was successful and the user is redirected to the home page
    }
}
