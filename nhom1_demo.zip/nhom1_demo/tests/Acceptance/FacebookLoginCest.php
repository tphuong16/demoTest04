<?php

class FacebookLoginCest
{
    // Test login with valid credentials
    public function loginWithValidCredentials($I)
    {
        $I->amOnPage('/'); 

        // Fill in the email and password fields and click the login button
        $I->fillField(['name' => 'email'], 'your@gmail.com');
        $I->fillField(['name' => 'pass'], 'your@password');
        $I->click(['name' => 'login']);

    }

    // Test login with invalid credentials
    public function loginWithInvalidCredentials($I)
    {
        $I->amOnPage('/'); 

        // Fill in the email and password fields with invalid data and click the login button
        $I->fillField(['name' => 'email'], 'invalid_email');
        $I->fillField(['name' => 'pass'], 'invalid_password');
        $I->click(['name' => 'login']);

        // Add assertions here to check if login failed (e.g., error message is displayed)
    }
}
